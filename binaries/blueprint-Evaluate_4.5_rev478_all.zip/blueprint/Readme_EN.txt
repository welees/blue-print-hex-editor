WeLees BluePrint(hereafter referred to as WBP) is a hexadecimal editor based on a Web front-end. Its back-end works on Windows, Linux and OSX platforms, and the Web-based front-end runs on any browser.
Users can start the back-end of WBP on PC/server/NAS/smart device(hereinafter referred to as the host) which has network connection, and perform graphical editing & analysis on data of the host in a browser on any other machine regardless of whether the host has local graphics module or not. Of course, you can also operate directly on host which has local graphics module.
WBP has 4 major advantages over other hexadecimal editors:

1. Remote access
   WBP allows users to perform operations on any device that can connect to host. The host is not required to be configured with I/O devices and local graphics modules.

2. Platform acrossing
   The back-end of WBP can run on Windows/Linux platforms and will support MAC in the future, so users need not to use other hexadecimal editor in different platforms.

3. Universal device support
   The WBP allows users to write private data access modules for certain non-standard devices according to data providing protocols, rather than providing only file/disk access like other editors. WBP comes with disk (Windows/Linux), partition (Linux), volume (Windows), and file (Windows) access modules to provide basic data access support. The source code for listed data providing modules can be found on Github, and users can easily modify the code to implement their own data providing modules.
   For example, with the memory data providing module, the WBP could be called GameMaster (who remember what this is).

4. Intelligent template
   WBP provides data parsing capabilities that users can use structural templates to parse data for analysis or any other purpose. Like the data providing protocol, the template format of WBP is open. Users can write their own structure templates via template protocol and sample templates. Because the WBP template is written in JavaScript, it can achieve very intelligent and powerful analysis capabilities. WBP comes with MBR,GPT,ZIP templates. You can easily write templates by referring these source code.

Launch method:

Windows: Run blueprint.bat [port]
  Port parameter specifies the port on which the editor works. If not specified, WBP uses port 80.
  Note: If you want to edit a disk/volume, you need to run on administrator privileges
  After the backend starts, run browser and access address
  http://back-end_IP_address:specified_port , for example, http://127.0.0.1:80

Linux: Execute blueprint [port]
  Port parameter specifies the port on which the editor works. If not specified, WBP uses port 80.
  Note: If you want to edit the disk, you need to run on administrator privileges
  After the backend starts, run browser and access address
  http://back-end_IP_address:specified_port , for example, http://127.0.0.1:80

If you want to access it remotely, do not forget to use address of host and enable the corresponding port on host.
