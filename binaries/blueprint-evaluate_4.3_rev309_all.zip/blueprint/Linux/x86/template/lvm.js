RegisterStructures();

function RegisterStructures()
{
	var lvmpvheader=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Physical Volume Header",
		Author:"Ares Lee",
		Group:"Disk",
		Type:"lvmpvheader",
		Name:"LVM Physical Volume Header",
		Size:["SectorSize",512], //For fixed size structure
		Parameters:{LabelSector:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800",StartOffset:"0"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"lvmheadersector",
				Desc:"Header Sector",
				Type:["LVM_lvmlabelheader","SectorSize",512],
				Repeat:4
			},
		]
	};
	
	var lvmlabelheader=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Physical Volume Label Header",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmlabelheader",
		Name:"LVM PV Label Header",
		Size:["SectorSize",512], //For fixed size structure
		Parameters:{StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:["char","",8], //uhex/hex/oct/uoct/udec/dec/bin/guid, bytes
				Value:function(Parameters,This,Base)
				{
					return [This.Val.signature,(This.Val.signature=="LABELONE")?1:-1];
				}
			},
			{
				Name:"labelheadersector",
				Desc:"Label Header Sector",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [parseInt(This.Val.labelheadersector,16),parseInt(MegaHexDivU(Base,Parameters.SectorSize),16)==parseInt(This.Val.labelheadersector,16)?1:-1];
				}
			},
			{
				Name:"crc",
				Desc:"CRC",
				Type:["uhex","",4], //uhex/hex/oct/uoct/udec/dec/bin, bytes
			},
			{
				Name:"pvheader2offset",
				Desc:"PV Header Offset",
				Type:["uhex","",4], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Ref:function(Parameters,This,Base)
				{
					var Result={};
					
					if(This.Val.signature=="LABELONE")
					{
						Result={Ref:{Group:"LVM",Type:["lvmlabelheader2"]},StartOffset:MegaHexAddU(Base,This.Val.pvheader2offset.toString(16)),Size:56,Parameters:{StartOffset:MegaHexAddU(Base,This.Val.pvheader2offset.toString(16)),StartSector:Parameters.StartSector,SectorSize:Parameters.SectorSize,TotalSectors:Parameters.TotalSectors}};
					}
					else
					{
						Result.NoRef=true;
					}
					
					return Result;
				}
			},
			{
				Name:"ver",
				Desc:"Version",
				Type:["char","",8], //uhex/hex/oct/uoct/udec/dec/bin/guid, bytes
			},
		]
	};
	
	var lvmlabelheaderext=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Physical Volume Label Header Extension",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmlabelheaderext",
		Name:"LVM PV Label Header Extension",
		Size:["SectorSize",24], //For fixed size structure
		Parameters:{StartOffset:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"version",
				Desc:"Version",
				Type:["uhex","",4], //uhex/hex/oct/uoct/udec/dec/bin/guid, bytes
				/*Value:function(Parameters,This,Base)
				{
					return [This.Val.signature,(This.Val.signature=="LABELONE")?1:-1];
				}*/
			},
			{
				Name:"flags",
				Desc:"Flags",
				Type:["uhex","",4], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [((parseInt(This.Val.flags,16)&1)?"InUse(":"Unused(")+AbbrValue(This.Val.flags)+"H)",0];
				}
			},
			{
				Name:"bootarea",
				Desc:"Boot Area Description",
				Type:["LVM_lvmsection","",16]
			},
		]
	};
	
	var lvmsection=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Section Description",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmsection",
		Name:"LVM Section",
		Size:["",16], //For fixed size structure
		Parameters:{StartOffseT:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"offset",
				Desc:"Offset",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.offset,16))+"("+AbbrValue(This.Val.offset)+"H)",0];
				}
			},
			{
				Name:"size",
				Desc:"Size",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.size,16))+"("+AbbrValue(This.Val.size)+"H)",0];
				}
			}
		]
	};
	
	var lvmlabelheader2=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM PV Label Header2",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmlabelheader2",
		Name:"LVM PV Label Header2",
		Size:["",56], //For fixed size structure
		Parameters:{StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"pvid",
				Desc:"UUID of PV",
				Type:["lvmuuid","",32], //uhex/hex/oct/uoct/udec/dec/bin/guid, bytes
				Value:function(Parameters,This,Base)
				{
					return [This.Val.pvid,0];
				}
			},
			{
				Name:"bytesinpv",
				Desc:"Bytes in PV",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.bytesinpv,16))+"("+AbbrValue(This.Val.bytesinpv)+"H)",0];
				}
			},
			{
				Name:"pesection",
				Desc:"PE Section",
				Type:["LVM_lvmpedesc","",16]
			},
		],
/*
		Next:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.pesection.offset,16))
			{//Section
				return [{
						Name:"pesection2",
						Desc:"PE Section2",
						Type:["LVM_lvmpedesc","",16]
					}];
			}
			else
			{
				return [{
						Name:"metasection",
						Desc:"Meta Section",
						Type:["LVM_lvmmetadesc","",16]
					}];
			}
		},
*/
	};
	
	var lvmpedesc=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Physical Volume Description",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmpedesc",
		Name:"LVM PV Description",
		Size:["",16], //For fixed size structure
		Parameters:{StartOffseT:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"offset",
				Desc:"Offset",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.offset,16))+"("+AbbrValue(This.Val.offset)+"H)",0];
				}
			},
			{
				Name:"size",
				Desc:"Size",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.size,16))+"("+AbbrValue(This.Val.size)+"H)",0];
				}
			}
		],
		Next:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.offset,16))
			{//Section
				return [{
						Name:"pesection2",
						Desc:"PE Section2",
						Type:["LVM_lvmpedesc","",16]
					}];
			}
			else
			{
				return [{
						Name:"metasection",
						Desc:"Meta Section",
						Type:["LVM_lvmmetadesc","",16]
					}];
			}
		},
	};
	
	var lvmmetadesc=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM Meta Data Section Description",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmmetadesc",
		Name:"LVM Meta Data Section",
		Size:["",16], //For fixed size structure
		Parameters:{StartOffset:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"offset",
				Desc:"Offset",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.offset,16))+"("+AbbrValue(This.Val.offset)+"H)",0];
				},
				Ref:function(Parameters,This,Base)
				{
					var Result={Ref:{},StartOffset:"",Size:""};
					if(MegaHexCompU(This.Val.offset,'0')==0)
					{
						Result.NoRef=true;
					}
					else
					{
						Result.Ref={Group:"LVM",Type:["lvmmetaheader"]};
						Result.StartOffset=This.Val.offset;
						Result.Size=64;
					}
					
					return Result;
				}
			},
			{
				Name:"size",
				Desc:"Size",
				Type:["uhex","",8], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.size,16))+"("+AbbrValue(This.Val.size)+"H)",0];
				}
			}
		],
		Next:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.offset,16))
			{//Section
				return [{
						Name:"metasection",
						Desc:"Meta Section2",
						Type:["LVM_lvmmetadesc","",16]
					}];
			}
			else
			{
				return [{
						Name:"lvmlabelheaderext",
						Desc:"Header Extension",
						Type:["LVM_lvmlabelheaderext","",16]
					}];
			}
		},
	};
	
	var lvmmetaheader=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Comment:"LVM PV Meta Data Header",
		Author:"Ares Lee",
		Group:"LVM",
		Type:"lvmmetaheader",
		Name:"LVM PV Meta Data Header",
		Size:["",64], //For fixed size structure
		Parameters:{StartOffset:'0',StartSector:'0',SectorSize:"200",TotalSectors:"800"}, //Default parameters, if user has not specified, parser will use these settings
		Members:
		[
			{
				Name:"crc",
				Desc:"CRC",
				Type:["uhex","",4], //uhex/hex/oct/uoct/udec/dec/bin/guid, bytes
			},
			{
				Name:"signature",
				Desc:"Signature",
				Type:["char","",16], //uhex/hex/oct/uoct/udec/dec/bin, bytes
				Value:function(Parameters,This,Base)
				{
					return [This.Val.signature,This.Val.signature==" LVM2 x[5A%r0N*>"?1:-1];
				}
			},
			{
				Name:"version",
				Desc:"Version",
				Type:["uhex","",4]
			},
			{
				Name:"offset",
				Desc:"Meta Area Start Offset",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.offset,16))+"("+AbbrValue(This.Val.offset)+"H)",0];
				}
			},
			{
				Name:"size",
				Desc:"Meta Area Size",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.size,16))+"("+AbbrValue(This.Val.size)+"H)",0];
				}
			},
			{
				Name:"curmetaoffset",
				Desc:"Current Meta Data Offset",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [MegaHexAddU("@"+This.Val.offset,This.Val.curmetaoffset)+"H("+AbbrValue(This.Val.curmetaoffset)+"H)",0];
				}
			},
			{
				Name:"curmetasize",
				Desc:"Current Meta Data Size",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.curmetasize)+"H",0];
				}
			},
			{
				Name:"crc",
				Desc:"CRC of Meta Data",
				Type:["uhex","",4]
			},
			{
				Name:"flags",
				Desc:"Flags",
				Type:["uhex","",4]
			},
		],
	};
	
	if(gStructureParser==undefined)
		setTimeout(RegisterDiskStructures,200);
	else
	{
		gStructureParser.Register(lvmpvheader);
		gStructureParser.Register(lvmlabelheader);
		gStructureParser.Register(lvmlabelheader2);
		gStructureParser.Register(lvmsection);
		gStructureParser.Register(lvmpedesc);
		gStructureParser.Register(lvmmetadesc);
		gStructureParser.Register(lvmlabelheaderext);
		gStructureParser.Register(lvmmetaheader);
	}
}
