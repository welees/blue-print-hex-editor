RegisterStructures(); //To register parser when script was loaded

function RegisterStructures()
{
	var structure={
		Vendor:"",
		Ver:"",
		Comment:"",
		Author:"",
		Group:"(1)Group",
		Type:"(2)Structure name",
		Name:"(3)Showing name",
		Size:["(4)Size from parameter",Structure default size], //For fixed size structure
		Parameters:{(5)Parameters for parsing current structure},
		Members:
		[
			{
				Name:"(6)Member name",
				Desc:"(7)Showing name",
				Type:['(8)Type',"(9)Size from parameter",(10)],
				Repeat:(11),
				Value:function(Parameters,This,Base)(12)optional
				{
				}
			},
		],
		Next:function(Parameters,This,Base)(13) Optional
		{
		},
		Neighbor:function(Parameters,This,Base)(14) Optional
		{
		}
	};
	
	if(gStructureParser==undefined)
		setTimeout(RegisterStructures,200);
	else
	{
		gStructureParser.Register(mbrpart);
		gStructureParser.Register(mbr);
		gStructureParser.Register(gptheader);
		gStructureParser.Register(gptentry);
	}
}

