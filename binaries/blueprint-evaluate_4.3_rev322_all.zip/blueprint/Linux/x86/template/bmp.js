RegisterStructures(); //To register parser when script was loaded

function RegisterStructures()
{
	var bmpheader={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Bitmap file header",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"bmpheader",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Bmp File Header",
		//The name shown on structure bar
		Size:["0",14], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					if(This.Val.signature=='4D42')
					{
						return ['BM',1];
					}
					else
					{
						return [This.Val.signature,-1];
					}
				}
			},
			{
				Name:"filesize",
				Desc:"File Size",
				Type:['uhex','',4],
/*
				Value:function(Parameters,This,Base)
				{
					if()
				}
*/
			},
			{
				Name:"pad",
				Desc:"Reserved",
				Type:['uhex','',4],
			},
			{
				Name:"bitoffset",
				Desc:"Bits Offset",
				Type:['uhex','',4],
			},
		],
		Neighbor:function(Parameters,This,Base)
		{
			return [["File","bmpinfoheader"]];//Multiple type maybe
		}
	};
	
	var infoheader={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Bitmap information header",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"bmpinfoheader",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Bmp Information Header",
		//The name shown on structure bar
		Size:["0",40],
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
/*
typedef struct {    // bmih
    DWORD   biSize;
    LONG    biWidth;
    LONG    biHeight;
    WORD    biPlanes;
    WORD    biBitCount;
    DWORD   biCompression;
    DWORD   biSizeImage;
    LONG    biXPelsPerMeter;
    LONG    biYPelsPerMeter;
    DWORD   biClrUsed;
    DWORD   biClrImportant;
} BITMAPINFOHEADER;
*/
			{
				Name:"infosize",
				Desc:"Information Size",
				Type:['uhex','',4],
			},
			{
				Name:"width",
				Desc:"Width",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					var a=new MegaNumberU(This.Val.width,16);
					return [a.ToDec(),0];
				}
			},
			{
				Name:"height",
				Desc:"Height",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					var a=new MegaNumberU(This.Val.height,16);
					return [a.ToDec(),0];
				}
			},
			{
				Name:"planes",
				Desc:"Planes",
				Type:['uhex','',2],
			},
			{
				Name:"bitsperpixel",
				Desc:"Bits Per Pixel",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var a=parseInt(This.Val.bitsperpixel,16);
					if(a==1)
					{
						return ["Mono",1];
					}
					else if(a==4)
					{
						return ["16 Colors",1];
					}
					else if(a==8)
					{
						return ["256 Colors",1];
					}
					else if(a==16)
					{
						return ["High Colors(64K)",1];
					}
					else if(a==24)
					{
						return ["True Colors(16M)",1];
					}
					else if(a==32)
					{
						return ["True Colors",1];
					}
					else
					{
						return ["Unknown("+a.toString(16).toUpperCase()+"H)",-1];
					}
				}
			},
			{
				Name:"compression",
				Desc:"Compression",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					var a=parseInt(This.Val.compression,16);
					if(a=0)
					{
						return ["Non-compressed",1];
					}
					else if(a==1)
					{
						return ["RLE8 Compression",1];
					}
					else if(a==2)
					{
						return ["RLE4 Compression",1];
					}
					else
					{
						return ["Unknown Compression("+a.toString(16).toUpperCase()+"H)",-1];
					}
				}
			},
			{
				Name:"sizeimage",
				Desc:"Size of Image",
				Type:['uhex','',4],
			},
			{
				Name:"xpixelofmeter",
				Desc:"X Pixel per Meter",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					var a=new MegaNumberU(This.Val.xpixelofmeter,16);
					return [a.ToDec(),0];
				}
			},
			{
				Name:"ypixelofmeter",
				Desc:"Y Pixel per Meter",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					var a=new MegaNumberU(This.Val.ypixelofmeter,16);
					return [a.ToDec(),0];
				}
			},
			{
				Name:"clrused",
				Desc:"Used Color Count",
				Type:['uhex','',4],
			},
			{
				Name:"clrimportant",
				Desc:"Important Color Count",
				Type:['uhex','',4],
			},
		],
/*
		Next:function(Parameters,This,Base)(13) Optional
		{
		},
		Neighbor:function(Parameters,This,Base)(14) Optional
		{
		}
*/
	};
	
	var rgbt={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Bitmap true color(24bit) color",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"bmprgbt",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Bmp Color",
		//The name shown on structure bar
		Size:["0",3],
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"blue",
				Desc:"Blue",
				Type:['uhex','',1],
			},
			{
				Name:"green",
				Desc:"Green",
				Type:['uhex','',1],
			},
			{
				Name:"red",
				Desc:"Red",
				Type:['uhex','',1],
			},
		]
	};
	
	var rgbq={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Bitmap true color(32bit) color",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"bmprgbq",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Bmp Color",
		//The name shown on structure bar
		Size:["0",4],
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"blue",
				Desc:"Blue",
				Type:['uhex','',1],
			},
			{
				Name:"green",
				Desc:"Green",
				Type:['uhex','',1],
			},
			{
				Name:"red",
				Desc:"Red",
				Type:['uhex','',1],
			},
			{
				Name:"reserved",
				Desc:"Reserved",
				Type:['uhex','',1],
			},
		]
	};
	
	if(gStructureParser==undefined)
		setTimeout(RegisterStructures,200);
	else
	{
		gStructureParser.Register(bmpheader);
		gStructureParser.Register(infoheader);
		gStructureParser.Register(rgbq);
		gStructureParser.Register(rgbt);
	}
}

