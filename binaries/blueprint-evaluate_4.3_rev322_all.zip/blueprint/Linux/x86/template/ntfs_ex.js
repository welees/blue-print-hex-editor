RegisterStructures();

function RegisterStructures()
{
	var restartpage=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"NTFS Log file restart page(this 1st/2nd page in log file",
		Author:"Ares Lee from welees.com",
		Type:"restartpage",
		Name:"NTFS Log File Restart Page",
		Size:["IndexRecordSize",4096], //For fixed size structure
		Parameters:{PageIndex:'0',FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					if(This.Val.signature=='52545352')
					{
						return ["RSTR",1];
					}
					else
					{
						return [This.Val.signature,-1];
					}
				},
			},
			{
				Name:"upseqoff",
				Desc:"Update Sequence Offset",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [This.Val.upseqoff,MegaHexCompU(This.Val.upseqoff,Parameters.IndexRecordSize)<0?1:-1];
				},
			},
			{
				Name:"upseqcount",
				Desc:"Update Sequence Count",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [This.Val.upseqcount,MegaHexCompU(((parseInt(This.Val.upseqcount,16)-1)*512).toString(16),Parameters.IndexRecordSize)==0?1:-1];
				},
			},
			{
				Name:"logrecord",
				Desc:"Chkdsk LSN",
				Type:["uhex","",8],
			},
			
			{
				Name:"syspagesize",
				Desc:"System Page Size",
				Type:["uhex","",4],
			},
			{
				Name:"logpagesize",
				Desc:"Log Page Size",
				Type:["uhex","",4],
			},
			{
				Name:"restartoffset",
				Desc:"Restart Data Offset",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [This.Val.restartoffset,((parseInt(This.Val.restartoffset,16)%8)==0)&&(MegaHexCompU(This.Val.restartoffset,Parameters.IndexRecordSize)<0)?1:-1];
				},
				Ref:function(Parameters,This,Base)
				{
					var Result={Ref:{Group:"NTFS",Type:["restartarea"]},StartOffset:MegaHexAddU(Base,This.Val.restartoffset),Size:Parameters.FileRecordSize};
					This.Parameters.StartSector=Parameters.StartSector;
					This.Parameters.SystemPageSize=This.Val.syspagesize;
					This.Parameters.LogPageSize=This.Val.logpagesize;
					
					return Result;
				}
			},
			{
				Name:"minor",
				Desc:"Minor Version",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.minor)+
					((parseInt(This.Val.major,16)>=1)&&
					 (parseInt(This.Val.minor,16)>0))?"/Support Packed Log":""
					,0];
				},
			},
			{
				Name:"major",
				Desc:"Major Version",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [parseInt(This.Val.major,16),0];
				},
			},
		],
		Neighbor:function(Parameters,This,Base)
		{
			This.Parameters.PageIndex=MegaHexAddU(This.Parameters.PageIndex,'1');
			if(MegaHexCompU(Parameters.PageIndex,'0')==0)
			{
				return [["NTFS","restartpage"]];
			}
			else
			{
				return [["NTFS","logdatapage"]];
			}
		}
	};
	
	var restartarea=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"NTFS log restart area header",
		Author:"Ares Lee from welees.com",
		Type:"restartarea",
		Name:"NTFS Log Restart Area Header",
		Size:["",320], //For fixed size structure
		Parameters:{SystemPageSize:'1000',LogPageSize:'1000',FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"curlsn",
				Desc:"Current LSN",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					var v=This.Val.curlsn,b=parseInt(This.Val.sequencebitnumber,16);
					debugger;
					v=MegaHexShlU(v,b);
					v=v.substr(v.length-16);
					v=MegaHexShrU(v,b-3);
					return [v+"H/"+MegaHexShrU(This.Val.curlsn,26)+"H("+AbbrValue(This.Val.curlsn)+"H)",0];
				},
			},
			{
				Name:"logclient",
				Desc:"Log Client",
				Type:["uhex","",2],
			},
			{
				Name:"clientfreelist",
				Desc:"Client Free List",
				Type:["uhex","",2],
			},
			{
				Name:"clientinuselist",
				Desc:"Client In Use List",
				Type:["uhex","",2],
			},
			{
				Name:"flags",
				Desc:"Flags",
				Type:["uhex","",2],
			},
			{
				Name:"sequencebitnumber",
				Desc:"Sequence Bit Number",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					var v=AbbrValue(This.Val.sequencebitnumber);
					This.Parameters.SequenceBitNumber=v;
					return [parseInt(v,16)+"("+v+"H)",0];
				},
			},
			{
				Name:"rsareasize",
				Desc:"Restart Area Size",
				Type:["uhex","",2],
/*
				Value:function(Parameters,This,Base)
				{
					return [This.Val.upseqcount,MegaHexCompU(((parseInt(This.Val.upseqcount,16)-1)*512).toString(16),Parameters.FileRecordSize)==0?1:-1];
				},
*/
			},
			{
				Name:"clientarrayoffset",
				Desc:"Client Array Offset",
				Type:["uhex","",2],
			},
			
			{
				Name:"filesize",
				Desc:"Log File Size",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					var v=AbbrValue(This.Val.filesize),R=[v,0];
					
					switch(v[0])
					{
						case '1':
							v=1+(v.length-1)*4;
							break;
						case '2':
						case '3':
							v=2+(v.length-1)*4;
							break;
						case '4':
						case '5':
						case '7':
						case '6':
							v=3+(v.length-1)*4;
							break;
						default:
							v=4+(v.length-1)*4;
							break;
					}
					This.Parameters.FileSizeBitNumber=v;
					R[0]+="H/File Size Bit="+v;
					return R;
				},
			},
			{
				Name:"lastlsndatasize",
				Desc:"Last LSN Data Size",
				Type:["uhex","",4],
			},
			{
				Name:"recordheadlength",
				Desc:"Record Head Length",
				Type:["uhex","",2],
			},
			{
				Name:"logpagedataoffset",
				Desc:"Log Page Data Offset",
				Type:["uhex","",2],
/*
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.minor)+
					((parseInt(This.Val.major,16)>=1)&&
					 (parseInt(This.Val.minor,16)>0))?"/Support Packed Log":""
					,0];
				},
*/
			},
			{
				Name:"restartopenlogcount",
				Desc:"Restart Open Log Count",
				Type:["uhex","",4],
			},
			{
				Name:"lastfailedflushstatus",
				Desc:"Status of Last Failed Flush",
				Type:["uhex","",4],
			},
			{
				Name:"lastfailedflushoffset",
				Desc:"Last Failed Flush Offset",
				Type:["uhex","",8],
			},
			{
				Name:"lastfailedflushlsn",
				Desc:"Last Failed Flush LSN",
				Type:["uhex","",8],
			},
			{
				Name:"clients",
				Desc:"Client Array",
				Type:["NTFS_clientrecord","",160],
			},
		],
/*
		Neighbor:function(Parameters,This,Base)
		{
			return [["NTFS","filerecord"]];//Multiple type maybe
		}
*/
	};
	var si=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of NTFS attribute standard information",
		Author:"Ares Lee from welees.com",
		Type:"si",
		Name:"* Attribute Data : Standard Information",
		Size:["",48],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"createtime",
				Desc:"Create Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastwritetime",
				Desc:"Last Modification Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastfrwritetime",
				Desc:"Last FileRecord Modification Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastaccesstime",
				Desc:"Last Access Time",
				Type:["uhex","",8],
			},
			{
				Name:"attributes",
				Desc:"File Attributes",
				Type:["uhex","",4],
			},
			{
				Name:"maxvernum",
				Desc:"Maximum Version Number",
				Type:["uhex","",4],
			},
			{
				Name:"vernum",
				Desc:"Version Number",
				Type:["uhex","",4],
			},
			{
				Name:"reserved",
				Desc:"Reserved",
				Type:["uhex","",4],
			},
		]
	}
	
	var fn=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of NTFS attribute file name",
		Author:"Ares Lee from welees.com",
		Type:"fn",
		Name:"* Attribute Data : File Name",
		Size:["",48],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"parent",
				Desc:"Parent Reference",
				Type:["NTFS_frr","",8],
			},
			{
				Name:"createtime",
				Desc:"Create Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastwritetime",
				Desc:"Last Modification Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastfrwritetime",
				Desc:"Last FileRecord Modification Time",
				Type:["uhex","",8],
			},
			{
				Name:"lastaccesstime",
				Desc:"Last Access Time",
				Type:["uhex","",8],
			},
			{
				Name:"allocatesize",
				Desc:"Allocated Size",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.allocatesize,16))+"("+AbbrValue(This.Val.allocatesize)+"H)",0];
				},
			},
			{
				Name:"filesize",
				Desc:"File Size",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.filesize,16))+"("+AbbrValue(This.Val.filesize)+"H)",0];
				},
			},
			{
				Name:"attributes",
				Desc:"File Attributes",
				Type:["uhex","",4],
			},
			{
				Name:"easize",
				Desc:"Packed EA Size",
				Type:["uhex","",2],
			},
			{
				Name:"reserved",
				Desc:"Reserved",
				Type:["uhex","",2],
			},
			{
				Name:"namelength",
				Desc:"Name Length",
				Type:["uhex","",1],
			},
			{
				Name:"namespace",
				Desc:"Name Type",
				Type:["uhex","",1],
				Value:function(Parameters,This,Base)
				{
					var r=["",1];
					if(This.Val.namespace=='00')
					{
						r[0]="Posix Name";
					}
					else if(This.Val.namespace=='01')
					{
						r[0]="Long File Name";
					}
					else if(This.Val.namespace=='02')
					{
						r[0]="Short File Name";
					}
					else if(This.Val.namespace=='03')
					{
						r[0]="Long/Short File Name";
					}
					else
					{
						r[0]="Unknown("+This.Val.namespace+"H)";
						r[1]=-1;
					}
					return r;
				},
			},
		],
		Next:function(Parameters,This,Base)
		{
			return [{Name:"filename",Desc:"File Name",Type:["unicode16","",parseInt((parseInt(This.Val.namelength,16)*2+9)/8)*8-2]}];
		},
	}
	
	var al=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of NTFS attribute $ATTRIBUTE_LIST, it is used to describe attributes in multiple file records.",
		Author:"Ares Lee from welees.com",
		Type:"al",
		Name:"* Attribute Data : Atribute List",
		Size:["",26],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"type",
				Desc:"Type",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					switch(parseInt(This.Val.type,16))
					{
						case 16:
							return ['Standard Information(10H)',1];
						case 32:
							return ['Attribute List(20H)',1];
						case 48:
							return ['File Name(30H)',1];
						case 64:
							return ['Object ID(40H)',1];
						case 80:
							return ['Security Descriptor(50H)',1];
						case 96:
							return ['Volume Name(60H)',1];
						case 112:
							return ['Volume Information(70H)',1];
						case 128:
							return ['Data(80H)',1];
						case 144:
							return ['Index Root(90H)',1];
						case 160:
							return ['Index Allocation(A0H)',1];
						case 176:
							return ['Bitmap(B0H)',1];
						case 192:
							return ['Symbolic Link(C0H)',1];
						case 208:
							return ['EA Information(D0H)',1];
						case 224:
							return ['EA(E0H)',1];
						case 240:
							return ['Property Set(F0H)',1];
						case 256:
							return ['Logged Utility Stream(100H)',1];
						case 0xffffffff:
							return ['Last Node(FFFFFFFFH)',1];
						default:
							return ['Unknown type('+AbbrValue(This.Val.type)+"H)",-1];
					}
				},
			},
			{
				Name:"size",
				Desc:"Record Size",
				Type:["uhex","",2],
			},
			{
				Name:"namesize",
				Desc:"Attribute Name Size",
				Type:["uhex","",1],
			},
			{
				Name:"nameoffset",
				Desc:"Attribute Name Offset",
				Type:["uhex","",1],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.nameoffset)+"H",MegaHexCompU(This.Val.nameoffset,'1a')==0?1:-1];
				},
			},
			{
				Name:"stargvcn",
				Desc:"Start VCN",
				Type:["uhex","",8],
			},
			{
				Name:"frr",
				Desc:"Host File Record",
				Type:["NTFS_frr","",8],
			},
			{
				Name:"id",
				Desc:"Attribute ID",
				Type:["uhex","",2],
			},
		],
		Next:function(Parameters,This,Base)
		{
			var v=parseInt(This.Val.namesize,16);
			if(v)
			{
				return [{Name:"attrname",Desc:"Attribute Name",Type:["unicode16","",parseInt((v*2+9)/8)*8-2]}];
			}
			else
			{
				return [];
			}
		},
/*		Neighbor:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.flags,16)&2)
			{
				return [];//Multiple type maybe
			}
			else
			{
				return [["NTFS","ief"]];//No neighbor, empty array
			}
		}
*/
	}
	
	var oi=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of Object ID Index Entry",
		Author:"Ares Lee from welees.com",
		Type:"oi",
		Name:"* Index Data : Object ID",
		Size:["",72],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"id",
				Desc:"ID",
				Type:["guid","",16],
			},
			{
				Name:"frr",
				Desc:"Host File Record Reference",
				Type:["NTFS_frr","",8],
			},
			{
				Name:"volumeid",
				Desc:"Create Volume ID",
				Type:["guid","",16],
			},
			{
				Name:"objectid",
				Desc:"Create Object ID",
				Type:["guid","",16],
			},
			{
				Name:"domainid",
				Desc:"Domain ID",
				Type:["guid","",16],
			},
		],
	}
	
	var vi=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of NTFS Attribute Volume Information",
		Author:"Ares Lee from welees.com",
		Type:"vi",
		Name:"* Attribute Data : Volume Information",
		Size:["",16],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"pad1",
				Desc:"Pad",
				Type:["uhex","",8],
			},
			{
				Name:"major",
				Desc:"Major Version",
				Type:["uhex","",1],
			},
			{
				Name:"minor",
				Desc:"Minor Version",
				Type:["uhex","",1],
			},
			{
				Name:"flags",
				Desc:"Flags",
				Type:["uhex","",2],
			},
			{
				Name:"pad2",
				Desc:"Pad",
				Type:["uhex","",4],
			},
		]
	}
	
	var ir=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Data of NTFS Attribute Index Root",
		Author:"Ares Lee from welees.com",
		Type:"ir",
		Name:"* Attribute Data : Index Root",
		Size:["",16],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"type",
				Desc:"Type",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					switch(parseInt(This.Val.type,16))
					{
						case 16:
							return ['Standard Information(10H)',1];
						case 32:
							return ['Attribute List(20H)',1];
						case 48:
							return ['File Name(30H)',1];
						case 64:
							return ['Object ID(40H)',1];
						case 80:
							return ['Security Descriptor(50H)',1];
						case 96:
							return ['Volume Name(60H)',1];
						case 112:
							return ['Volume Information(70H)',1];
						case 128:
							return ['Data(80H)',1];
						case 144:
							return ['Index Root(90H)',1];
						case 160:
							return ['Index Allocation(A0H)',1];
						case 176:
							return ['Bitmap(B0H)',1];
						case 192:
							return ['Symbolic Link(C0H)',1];
						case 208:
							return ['EA Information(D0H)',1];
						case 224:
							return ['EA(E0H)',1];
						case 240:
							return ['Property Set(F0H)',1];
						case 256:
							return ['Logged Utility Stream(100H)',1];
						case 0xffffffff:
							return ['Last Node(FFFFFFFFH)',1];
						default:
							return ['Unknown type('+AbbrValue(This.Val.type)+"H)",-1];
					}
				},
			},
			{
				Name:"collationrule",
				Desc:"Collation Rule",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					This.Parameters.Rule=parseInt(This.Val.collationrule,16);
					switch(parseInt(This.Val.collationrule,16))
					{
						case 0:
							return ["Binary(0)",1];
						case 1:
							return ["FileName(1)",1];
						case 2:
							return ["Unicode(2)",1];
						case 16:
							return ["ULONG(10H)",1];
						case 17:
							return ["Security ID(11H)",1];
						case 18:
							return ["Security Hash(12H)",1];
						case 19:
							return ["ULONG List(13H)",1];
						default:
							return ["Unknown("+This.Val.collationrule+")",-1];
					}
				},
			},
			{
				Name:"irsize",
				Desc:"Index Record Size",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					return [getSize(parseInt(This.Val.irsize,16))+"("+AbbrValue(This.Val.irsize)+"H)",MegaHexCompU(This.Val.irsize,Parameters.IndexRecordSize)==0?1:-1];
				}
			},
			{
				Name:"cpi",
				Desc:"Clusters per IndexRecord",
				Type:["uhex","",4],
			},
		]
	}
	
	var ief=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"File/Directory Index Entry, to index file object in B tree",
		Author:"Ares Lee from welees.com",
		Type:"ief",
		Name:"Index Entry : File name",
		Size:["",16],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"frr",
				Desc:"File Record Reference",
				Type:["NTFS_frr","",8],
			},
			{
				Name:"entrysize",
				Desc:"Entry Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.entrysize)+"H",0];
				},
			},
			{
				Name:"keysize",
				Desc:"Key Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.keysize)+"H",0];
				},
			},
			{
				Name:"flags",
				Desc:"Index Flags",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					var r=["",0],v=parseInt(This.Val.flags,16);
					if(v&1)
					{
						r[0]+="Branch Entry,";
					}
					if(v&2)
					{
						r[0]+="Last Entry,";
					}
					r[0]=r[0].substr(0,r[0].length-1);
					return r;
				},
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",2],
			},
		],
		Next:function(Parameters,This,Base)
		{
			var v=parseInt(This.Val.flags,16),r=[];
			if(!(v&2))
			{
				r.push({Name:"fileinfo",Desc:"File Information",Type:["NTFS_fn","",parseInt((parseInt(This.Val.keysize,16)+7)/8)*8]});
			}
			if(v&1)
			{
				r.push({Name:"childoffset",Desc:"Child Record Virtual Cluster Offset",Type:["uhex","",8]});
			}
			
			return r;
		},
		Neighbor:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.flags,16)&2)
			{
				return [];//Multiple type maybe
			}
			else
			{
				return [["NTFS","ief"]];//No neighbor, empty array
			}
		}
	}
	
	var ieoi=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Object ID Index Entry, to index object ID in B tree",
		Author:"Ares Lee from welees.com",
		Type:"ieoi",
		Name:"Index Entry : Object ID",
		Size:["",16],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"dataoffset",
				Desc:"Data Offset",
				Type:["uhex","",2],
			},
			{
				Name:"datasize",
				Desc:"Data Size",
				Type:["uhex","",2],
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",4],
			},
			{
				Name:"entrysize",
				Desc:"Entry Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.entrysize)+"H",0];
				},
			},
			{
				Name:"keysize",
				Desc:"Key Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.keysize)+"H",0];
				},
			},
			{
				Name:"flags",
				Desc:"Index Flags",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					var r=["",0],v=parseInt(This.Val.flags,16);
					if(v&1)
					{
						r[0]+="Branch Entry,";
					}
					if(v&2)
					{
						r[0]+="Last Entry,";
					}
					r[0]=r[0].substr(0,r[0].length-1);
					return r;
				},
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",2],
			},
		],
		Next:function(Parameters,This,Base)
		{
			var v=parseInt(This.Val.flags,16),r=[];
			if(!(v&2))
			{
				r.push({Name:"objectid",Desc:"ObjectID",Type:["NTFS_oi","",parseInt(This.Val.entrysize,16)-parseInt(This.Val.keysize,16)]});
			}
			if(v&1)
			{
				r.push({Name:"childoffset",Desc:"Child Record Virtual Cluster Offset",Type:["uhex","",8]});
			}
			
			return r;
		},
		Neighbor:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.flags,16)&2)
			{
				return [];//Multiple type maybe
			}
			else
			{
				return [["NTFS","ieoi"]];//No neighbor, empty array
			}
		}
	}
	
	var iesh=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Security Hash Index Entry, to index security object in B tree",
		Author:"Ares Lee from welees.com",
		Type:"iesh",
		Name:"Index Entry : Security Hash",
		Size:["",48],
		Parameters:{},
		Members:
		[
			{
				Name:"dataoffset",
				Desc:"Data Offset",
				Type:["uhex","",2],
			},
			{
				Name:"datasize",
				Desc:"Data Size",
				Type:["uhex","",2],
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",4],
			},
			{
				Name:"entrysize",
				Desc:"Entry Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.entrysize)+"H",0];
				},
			},
			{
				Name:"keysize",
				Desc:"Key Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.keysize)+"H",0];
				},
			},
			{
				Name:"flags",
				Desc:"Index Flags",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					var r=["",0],v=parseInt(This.Val.flags,16);
					if(v&1)
					{
						r[0]+="Branch Entry,";
					}
					if(v&2)
					{
						r[0]+="Last Entry,";
					}
					r[0]=r[0].substr(0,r[0].length-1);
					return r;
				},
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",2],
			},
			
			{
				Name:"key",
				Desc:"Index Key",
				Type:["NTFS_hashindex","",8],
			},
			{
				Name:"key",
				Desc:"Key",
				Type:["NTFS_hashindex","",8],
			},
			{
				Name:"offset",
				Desc:"Offset In File",
				Type:["uhex","",8],
			},
			{
				Name:"size",
				Desc:"Data Size",
				Type:["uhex","",4],
			},
		],
		Neighbor:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.flags,16)&2)
			{
				return [];//Multiple type maybe
			}
			else
			{
				return [["NTFS","iesh"]];//No neighbor, empty array
			}
		}
	}
	
	var iesi=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Security Index Entry, to index security object in B tree",
		Author:"Ares Lee from welees.com",
		Type:"iesi",
		Name:"Index Entry : Security Index",
		Size:["",40],
		Parameters:{},
		Members:
		[
			{
				Name:"dataoffset",
				Desc:"Data Offset",
				Type:["uhex","",2],
			},
			{
				Name:"datasize",
				Desc:"Data Size",
				Type:["uhex","",2],
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",4],
			},
			{
				Name:"entrysize",
				Desc:"Entry Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.entrysize)+"H",0];
				},
			},
			{
				Name:"keysize",
				Desc:"Key Size",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.keysize)+"H",0];
				},
			},
			{
				Name:"flags",
				Desc:"Index Flags",
				Type:["uhex","",2],
				Value:function(Parameters,This,Base)
				{
					var r=["",0],v=parseInt(This.Val.flags,16);
					if(v&1)
					{
						r[0]+="Branch Entry,";
					}
					if(v&2)
					{
						r[0]+="Last Entry,";
					}
					r[0]=r[0].substr(0,r[0].length-1);
					return r;
				},
			},
			{
				Name:"pad",
				Desc:"Pad",
				Type:["uhex","",2],
			},
			
			{
				Name:"index",
				Desc:"Security Descriptor Index",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.index)+"H",0];
				}
			},
			{
				Name:"key",
				Desc:"Key",
				Type:["NTFS_hashindex","",8],
			},
			{
				Name:"offset",
				Desc:"Offset In File",
				Type:["uhex","",8],
			},
			{
				Name:"size",
				Desc:"Data Size",
				Type:["uhex","",4],
			},
		],
		Neighbor:function(Parameters,This,Base)
		{
			if(parseInt(This.Val.flags,16)&2)
			{
				return [];//Multiple type maybe
			}
			else
			{
				return [["NTFS","iesi"]];//No neighbor, empty array
			}
		}
	}
	
	var hashindex=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Security data hash index",
		Author:"Ares Lee from welees.com",
		Type:"hashindex",
		Name:"* Hash Index",
		Size:["",8],
		Parameters:{},
		Members:
		[
			{
				Name:"hash",
				Desc:"Hash Value",
				Type:["uhex","",4],
			},
			{
				Name:"index",
				Desc:"Security Descriptor Index",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					return [AbbrValue(This.Val.index)+"H",0];
				}
			},
		],
	}
	
	var ea=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"EA Information, used for $EA Attribute",
		Author:"Ares Lee from welees.com",
		Type:"ea",
		Name:"* EA Information",
		Size:["",8],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"packedsize",
				Desc:"Packed EA Size",
				Type:["uhex","",2],
			},
			{
				Name:"needeacount",
				Desc:"Needed EA Count",
				Type:["uhex","",2],
			},
			{
				Name:"size",
				Desc:"Unpacked EA Size",
				Type:["uhex","",4],
			},
		],
	}
	
	var ih=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"Index Data Header, used for $IndexRoot Attribute and IndexRecord",
		Author:"Ares Lee from welees.com",
		Type:"ih",
		Name:"* Index Data Header",
		Size:["",16],
		Parameters:{FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"entryoffset",
				Desc:"First Index Entry Offset",
				Type:["uhex","",4],
				Ref:function(Parameters,This,Base)
				{debugger;
					var Result={Ref:{Group:"NTFS",Type:["ief"]},StartOffset:MegaHexAddU(Base,This.Val.entryoffset),Size:"10"};
					This.Parameters.StartSector=Parameters.StartSector;
					This.Parameters.StartOffset=Result.StartOffset;
					
					switch(Parameters.Rule)
					{
						case 0:
							debugger;
							break;
						case 1:
							Result.Ref.Type=["ief"];
							break;
						case 2:
							debugger;
							break;
						case 16:
							debugger;
							break;
						case 17:
							Result.Ref.Type=["iesi"];
							break;
						case 18:
							Result.Ref.Type=["iesh"];
							break;
						case 19:
							Result.Ref.Type=["ieoi"];
							break;
						default:
							debugger;
							break;
					}
					return Result;
				}
			}, 
			{
				Name:"datasize",
				Desc:"Size of Index Node(Header+Entries)",
				Type:["uhex","",4],
			},
			{
				Name:"allocatesize",
				Desc:"Allocated Size",
				Type:["uhex","",4],
			},
			{
				Name:"flags",
				Desc:"Flags",
				Type:["uhex","",4],
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.flags,16);
					if(v&1)
					{
						return ["Branch node",1];
					}
					else
					{
						return ["Leaf node",1];
					}
				}
			},
		],
	}
	
	var lsn=
	{
		Vendor:"weLees Co., LTD",
		Ver:"1.0.0",
		Group:"NTFS",
		Comment:"NTFS Log record index/check data",
		Author:"Ares Lee from welees.com",
		Type:"lsn",
		Name:"NTFS Log record index",
		Size:["",8],
		Parameters:{StartSector:'0',FileSizeBitNumber:'1',SequenceBitNumber:'1',FileRecordSize:'400',IndexRecordSize:"1000",TotalSetors:'10000',SectorsPerCluster:"8",SectorSize:'200'},
		Members:
		[
			{
				Name:"data",
				Desc:"Log Index",
				Type:["uhex","",8],
				Value:function(Parameters,This,Base)
				{debugger;
					var Result=[],Offset=MegaHexAnd(MegaHexSubU(MegaHexShlU('1',Parameters.FileSizeBitNumber),'1'),This.Val.data);
				}
			}, 
		],
	}
	
	if(gStructureParser==undefined)
		setTimeout(RegisterStructures,200);
	else
	{
		gStructureParser.Register(restartpage);
		gStructureParser.Register(restartarea);
		gStructureParser.Register(si);
		gStructureParser.Register(al);
		gStructureParser.Register(fn);
		gStructureParser.Register(oi);
		gStructureParser.Register(vi);
		gStructureParser.Register(ir);
		gStructureParser.Register(ih);
		gStructureParser.Register(ief);
		gStructureParser.Register(ieoi);
		gStructureParser.Register(iesh);
		gStructureParser.Register(iesi);
		gStructureParser.Register(hashindex);
	}
}
