The WeLees BinEditor Remote is a hexadecimal editor based on the Web front-end. Its back end supports both Linux and Windows platforms. The Web-based front-end allows it to run on any browser.
Users can run WBE Remote on any host to access/edit data in graphical mode regardless of whether graphics module was installed on host. User can also work with any other machine which can connect to the host that WBE Remote running on.
The biggest advantages of WBE Remote over other hexadecimal editors are remote access and extensibility. The WBE Remote itself does not provide object provide module (the provide modules in package are just for demonstration, communication protocol and demonstration source will soon be uploaded to our official website and Github, users can download them), users can write their own provide module according to the communicate protocol as request.
For example, with a process memory provide module,  the WBE Remote can be called Game Experter(wish someone remember what it is lol).

Usage:
  Windows: Execute weleesbineditor.exe [Port]

  The parameter specified the port editor works with, or 80 if not specified. Note: If you want to edit diskvolume, you need to run as administrator
  After back-end launched, open browser and input
  http://IP of back-end:port specified    such as : http://127.0.0.1:80

  Linux: Execute weLeesBinEditor [Port]

  The parameter specified the port editor works with, or 80 if not specified. Note: If you want to edit the disk, you need to run with root privileges
  After back-end launched, open browser and input
  http://IP of back-end:port specified    such as : http://127.0.0.1:80
