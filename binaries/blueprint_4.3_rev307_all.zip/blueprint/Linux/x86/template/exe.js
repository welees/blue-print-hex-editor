RegisterStructures(); //To register parser when script was loaded

function RegisterStructures()
{
	var mzheader={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft execute file, include MZ/Port16/Port32/Port64",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"msdosexeheader",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Microsoft EXE File Header",
		//The name shown on structure bar
		Size:["0",64], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					if(This.Val.signature=='5A4D')
					{
						return ['MZ',1];
					}
					else
					{
						return [This.Val.signature,-1];
					}
				}
			},
			{
				Name:"bytesinlastpage",
				Desc:"Used Bytes In Last Page",
				Type:['uhex','',2],
			},
			{
				Name:"pages",
				Desc:"Pages of File",
				Type:['uhex','',2],
			},
			{
				Name:"relocatecount",
				Desc:"Relocate Item Count",
				Type:['uhex','',2],
			},
			{
				Name:"parasperheader",
				Desc:"Size of Header in Paragraphs",
				Type:['uhex','',2],
			},
			{
				Name:"minextpara",
				Desc:"Minimum Extra Paragraphs Needed",
				Type:['uhex','',2],
			},
			{
				Name:"maxextpara",
				Desc:"Maximum Extra Paragraphs Needed",
				Type:['uhex','',2],
			},
			{
				Name:"initss",
				Desc:"Start SS",
				Type:['uhex','',2],
			},
			{
				Name:"initsp",
				Desc:"Start SP",
				Type:['uhex','',2],
			},
			{
				Name:"checksum",
				Desc:"Check Sum",
				Type:['uhex','',2],
			},
			{
				Name:"initip",
				Desc:"Start IP",
				Type:['uhex','',2],
			},
			{
				Name:"initcs",
				Desc:"Start CS",
				Type:['uhex','',2],
			},
			{
				Name:"relocateoffset",
				Desc:"Relocate Table Offset",
				Type:['uhex','',2],
			},
			{
				Name:"overlaynumber",
				Desc:"Overlay Number",
				Type:['uhex','',2],
			},
			{
				Name:"reserved",
				Desc:"Reserved",
				Type:['uhex','',8],
			},
			{
				Name:"oemid",
				Desc:"OEM ID",
				Type:['uhex','',2],
			},
			{
				Name:"oeminfo",
				Desc:"OEM Information",
				Type:['uhex','',2],
			},
			{
				Name:"reserved2",
				Desc:"Reserved2",
				Type:['uhex','',20],
			},
			{
				Name:"ntoffset",
				Desc:"PE Header Offset",
				Type:['uhex','',4],
				Ref:function(Parameters,This,Base)
				{
					return {Ref:{Group:"File",Type:["mspeheader"]},StartOffset:MegaHexAddU(Base,This.Val.ntoffset),Size:"18"};
				}
			},
		],
/*
		Neighbor:function(Parameters,This,Base)
		{
			return [["File","bmpinfoheader"]];//Multiple type maybe
		}
*/
	};
	
	var peheader={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft portable execute format, for 16/32/64bit Windows platform",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"mspeheader",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Microsoft Portable Execute File Header",
		//The name shown on structure bar
		Size:["0",24], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:['uhex','',4],
				Value:function(Parameters,This,Base)
				{
					if(This.Val.signature=='00004550')
					{
						return ['PE',1];
					}
					else
					{
						return [This.Val.signature,-1];
					}
				}
			},
			{
				Name:"machine",
				Desc:"Work Machine",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var t=[['IA32',0x014c],
						   ['R3000',0x0162],
						   ['R4000',0x0166],
    					   ['R10000',0x0168],
    					   ['WCEMIPSV2',0x0169],
    					   ['Alpha',0x0184],
    					   ['Hitachi SH3',0x01a2],
    					   ['Hitachi SH3 DSP',0x01a3],
    					   ['Hitachi SH3E',0x01a4],
    					   ['Hitachi SH4',0x01a6],
    					   ['Hitachi SH5',0x01a8],
    					   ['ARM',0x01c0],
    					   ['Thumb',0x01c2],
    					   ['ARM Thumb2',0x01c4],
    					   ['AM33',0x01d3],
    					   ['Power PC',0x01f0],
    					   ['Power PC&FP',0x01f1],
    					   ['Itanium',0x0200],
    					   ['MIPS16',0x0266],
    					   ['Alpha64',0x0284],
    					   ['MIPS&FPU',0x0366],
    					   ['MIPS16&FPU',0x0466],
    					   ['TRICORE',0x0520],
    					   ['CEF',0x0CEF],
    					   ['EBC',0x0EBC],
    					   ['RISC-V 32',0x5032],
    					   ['RISC-V 64',0x5064],
    					   ['RISC-V 128',0x5128],
    					   ['AMD64/x86_64',0x8664],
    					   ['M32R',0x9041],
    					   ['ARM64',0xAA64],
    					   ['CEE',0xC0EE]],v=parseInt(This.Val.machine,16),i,Result=["Unknown("+AbbrValue(This.Val.machine)+"H)",-1];
					for(i=0;i<t.length;i++)
					{
						if(v==t[i][1])
						{
							Result=[t[i][0],1];
							break;
						}
					}
					return Result;
				}
			},
			{
				Name:"sectionnumber",
				Desc:"Section Number",
				Type:['uhex','',2],
			},
			{
				Name:"time",
				Desc:"Create Time",
				Type:['uhex','',4],
			},
			{
				Name:"symtaboff",
				Desc:"Symbol Table Offset",
				Type:['uhex','',4],
			},
			{
				Name:"symcount",
				Desc:"Symbol Count",
				Type:['uhex','',4],
			},
			{
				Name:"optheadsize",
				Desc:"Optinal Header Size",
				Type:['uhex','',2],
			},
			{
				Name:"chars",
				Desc:"File Characteristics",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.chars,16),r='';
					if(v&1)
					{
						r+="Relocation info stripped from file<br>";
					}
					if(v&2)
					{
						r+="Executable<br>";
					}
					if(v&4)
					{
						r+="Line nunbers stripped from file<br>";
					}
					if(v&8)
					{
						r+="Local symbols stripped from file<br>";
					}
					if(v&16)
					{
						r+="Agressively trim working set<br>";
					}
					if(v&32)
					{
						r+="App can access 2GB+ addresses<br>";
					}
					if(v&128)
					{
						r+="Bytes of machine word are reversed<br>";
					}
					if(v&256)
					{
						r+="32 bits word machine<Br>";
					}
					if(v&512)
					{
						r+="Debugging info stripped from file in .DBG file<br>";
					}
					if(v&1024)
					{
						r+="If Image is on removable media, copy and run from the swap file<br>";
					}
					if(v&2048)
					{
						r+="If Image is on Net, copy and run from the swap file<br>";
					}
					if(v&4096)
					{
						r+="System File<br>";
					}
					if(v&8192)
					{
						r+="DLL file<br>";
					}
					if(v&16384)
					{
						r+="File should only be run on a UP machine<br>";
					}
					if(v&32768)
					{
						r+="Bytes of machine word are reversed<br>";
					}
					return [r,0];
				}
			},
		],
		Next:function(Parameters,This,Base)
		{
			return [{Name:"optheader",Desc:"Optional Header",Type:["File_mspeoptheader","",2]}];
		}
	};
	
	var optheader={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft portable execute format, optional header",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"mspeoptheader",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Microsoft Portable Execute Optional Header",
		//The name shown on structure bar
		Size:["0",2], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"signature",
				Desc:"Signature",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.signature,16);
					if(v==0x10b)
					{
						return ['32 Bits PE',1];
					}
					else if(v==0x107)
					{
						return ["ROM",1];
					}
					else if(v==0x20b)
					{
						return ["64 Bits PE",1];
					}
					else
					{
						return ["Unknown("+AbbrValue(This.Val.signature)+"H)",-1];
					}
				}
			},
		],
		Next:function(Parameters,This,Base)
		{
			var v=parseInt(This.Val.signature,16);
			if(v==0x10b)
			{
				return [{Name:"optheader32",Desc:"32 Bits Optional Header",Type:["File_mspeoptheader32","",94]}];
			}
			else if(v==0x107)
			{
			debugger;
				return [{Name:"optheader32",Desc:"32 Bits Optional Header",Type:["File_mspeoptheader32","",94]}];
			}
			else if(v==0x20b)
			{
				return [{Name:"optheader64",Desc:"64 Bits Optional Header",Type:["File_mspeoptheader64","",110]}];
			}
			else
			{
				return [];
			}
		}
	};
	
	
	var datadir={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft portable execute format, Data Directory",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"mspedatadir",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"Microsoft Portable Execute Data Direcory",
		//The name shown on structure bar
		Size:["0",8], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"address",
				Desc:"Virtual Address",
				Type:['uhex','',4],
/*
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.signature,16);
					if(v==0x10b)
					{
						return ['32 Bits PE',1];
					}
					else if(v==0x107)
					{
						return ["ROM",1];
					}
					else if(v==0x20b)
					{
						return ["64 Bits PE",1];
					}
				}
*/
			},
			{
				Name:"size",
				Desc:"Size",
				Type:['uhex','',4],
			},
		],
	};
	
	var optheader32={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft portable execute format, 32 bits optional header",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"mspeoptheader32",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"* Microsoft Portable Execute 32 bits Optional Header",
		//The name shown on structure bar
		Size:["0",94], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"majorlink",
				Desc:"Linker Major Version",
				Type:['uhex','',1],
			},
			{
				Name:"minorlink",
				Desc:"Linker Minor Version",
				Type:['uhex','',1],
			},
			{
				Name:"codesize",
				Desc:"Code Size",
				Type:['uhex','',4],
			},
			{
				Name:"initsize",
				Desc:"Initialized Data Size",
				Type:['uhex','',4],
			},
			{
				Name:"uninitsize",
				Desc:"Uninitialized Data Size",
				Type:['uhex','',4],
			},
			{
				Name:"entry",
				Desc:"EXE Start Point",
				Type:['uhex','',4],
				//Value:function---------------------
				//DWORD       AddressOfEntryPoint <format=hex,comment=CommentRVA2FOA>;
			},
			{
				Name:"codebase",
				Desc:"Code Base",
				Type:['uhex','',4],
			},
			{
				Name:"database",
				Desc:"Data Base",
				Type:['uhex','',4],
			},
			{
				Name:"imgbase",
				Desc:"Image Base",
				Type:['uhex','',4],
			},
			{
				Name:"secalign",
				Desc:"Section Alignment",
				Type:['uhex','',4],
			},
			{
				Name:"filealign",
				Desc:"File Alignment",
				Type:['uhex','',4],
			},
			{
				Name:"osmajor",
				Desc:"OS Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"osminor",
				Desc:"OS Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"imgmajor",
				Desc:"Image Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"imgminor",
				Desc:"Image Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"subsysmajor",
				Desc:"Sub-System Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"subsysminor",
				Desc:"Sub-System Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"w32ver",
				Desc:"Windows 32 Version",
				Type:['uhex','',4],
			},
			{
				Name:"imgsize",
				Desc:"Image Size",
				Type:['uhex','',4],
			},
			{
				Name:"hdsize",
				Desc:"Header Size",
				Type:['uhex','',4],
			},
			{
				Name:"checksum",
				Desc:"Check Sum",
				Type:['uhex','',4],
			},
			{
				Name:"imgsubsys",
				Desc:"Image Sub-System",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=["Unknown sub-system",
						   "Native",
						   "Windows GUI",
						   "Windows CLI",
						   "Unknown sub-system",
						   "OS/2",
						   "Unknown sub-system",
						   "Posix",
						   "Native Windows 9x Driver",
						   "Windows CE GUI",
						   "EFI Application",
						   "EFI Boot Service Driver",
						   "EFI Runtime Driver",
						   "EFI ROM",
						   "XBOX",
						   "Unknown sub-system",
						   "Windows Boot Application"],t=parseInt(This.Val.imgsubsys,16),Result=[0,1];
					if((t<0)||(t>=v.length))
					{
						t=0;
						Result[1]=-1;
					}
					Result[0]=v[t];
					return Result;
				}
			},
			{
				Name:"dllchars",
				Desc:"DLL Characteristics",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.dllchars,16),r='';
					if(v&64)
					{
						r+="Dynamical Base<br>";
					}
					if(v&128)
					{
						r+="Code Integrity Image<br>";
					}
					if(v&256)
					{
						r+="NX Compatible<Br>";
					}
					if(v&512)
					{
						r+="No isolation<br>";
					}
					if(v&1024)
					{
						r+="No SEH<br>";
					}
					if(v&2048)
					{
						r+="No Bind<br>";
					}
					if(v&8192)
					{
						r+="WDM Driver<br>";
					}
					if(v&32768)
					{
						r+="Terminate Service Aware<br>";
					}
					return [r,0];
				}
			},
			{
				Name:"stacksize",
				Desc:"Reserved Stack Size",
				Type:['uhex','',4],
			},
			{
				Name:"stackcommitsize",
				Desc:"Committed Stack Size",
				Type:['uhex','',4],
			},
			{
				Name:"heapsize",
				Desc:"Reserved Heap Size",
				Type:['uhex','',4],
			},
			{
				Name:"heapcommitsize",
				Desc:"Committed Heap Size",
				Type:['uhex','',4],
			},
			{
				Name:"loaderflags",
				Desc:"Loader Flags",
				Type:['uhex','',4],
			},
			{
				Name:"rvacount",
				Desc:"RVA Table Count",
				Type:['uhex','',4],
			},
		],
		Next:function(Parameters,This,Base)
		{
			var d=[
				{Name:"export",Desc:"Export",Type:["File_mspedatadir","",8]},
				{Name:"import",Desc:"Import",Type:["File_mspedatadir","",8]},
				{Name:"resource",Desc:"Resource",Type:["File_mspedatadir","",8]},
				{Name:"exception",Desc:"Exception",Type:["File_mspedatadir","",8]},
				{Name:"security",Desc:"Security",Type:["File_mspedatadir","",8]},
				{Name:"relocatetable",Desc:"RelocationTable",Type:["File_mspedatadir","",8]},
				{Name:"debug",Desc:"DebugDirectory",Type:["File_mspedatadir","",8]},
				{Name:"copyright",Desc:"CopyrightOrArchitectureSpecificData",Type:["File_mspedatadir","",8]},
				{Name:"global",Desc:"GlobalPtr",Type:["File_mspedatadir","",8]},
				{Name:"tls",Desc:"TLSDirectory",Type:["File_mspedatadir","",8]},
				{Name:"config",Desc:"LoadConfigurationDirectory",Type:["File_mspedatadir","",8]},
				{Name:"bound",Desc:"BoundImportDirectory",Type:["File_mspedatadir","",8]},
				{Name:"importaddrtable",Desc:"ImportAddressTable",Type:["File_mspedatadir","",8]},
				{Name:"delayload",Desc:"DelayLoadImportDescriptors",Type:["File_mspedatadir","",8]},
				{Name:"com",Desc:"COMRuntimedescriptor",Type:["File_mspedatadir","",8]},
				{Name:"reserved",Desc:"Reserved",Type:["File_mspedatadir","",8]}
			],v=parseInt(This.Val.rvacount,16);
			
			if(v>16)
			{
				v=16;
			}
			return d.slice(0,v);
		}
	};
	
	var optheader64={
		Vendor:"weLees Co., LTD",
		//vendor information
		Ver:"1.0.0",
		Comment:"Microsoft portable execute format, 64 bits optional header",
		Author:"Ares Lee from welees.com",
		Group:"File",
		//Group of structure
		Type:"mspeoptheader64",
		//The type of structure, just like int/guid. other structures refer current structure by the type
		Name:"* Microsoft Portable Execute 64 bits Optional Header",
		//The name shown on structure bar
		Size:["0",110], 
		//The size of structure.
		//  The 1st element is size for dynamical structure, it must be name of member of Parameters from device/previous structure parser, if structure is fixed size, it should be ""
		//  The 2nd element is the default size of fixed size of structure
		Parameters:{},
		Members:
		[
			{
				Name:"majorlink",
				Desc:"Linker Major Version",
				Type:['uhex','',1],
			},
			{
				Name:"minorlink",
				Desc:"Linker Minor Version",
				Type:['uhex','',1],
			},
			{
				Name:"codesize",
				Desc:"Code Size",
				Type:['uhex','',4],
			},
			{
				Name:"initsize",
				Desc:"Initialized Data Size",
				Type:['uhex','',4],
			},
			{
				Name:"uninitsize",
				Desc:"Uninitialized Data Size",
				Type:['uhex','',4],
			},
			{
				Name:"entry",
				Desc:"EXE Start Point",
				Type:['uhex','',4],
				//Value:function---------------------
				//DWORD       AddressOfEntryPoint <format=hex,comment=CommentRVA2FOA>;
			},
			{
				Name:"codebase",
				Desc:"Code Base",
				Type:['uhex','',4],
			},
			{
				Name:"imgbase",
				Desc:"Image Base",
				Type:['uhex','',8],
			},
			{
				Name:"secalign",
				Desc:"Section Alignment",
				Type:['uhex','',4],
			},
			{
				Name:"filealign",
				Desc:"File Alignment",
				Type:['uhex','',4],
			},
			{
				Name:"osmajor",
				Desc:"OS Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"osminor",
				Desc:"OS Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"imgmajor",
				Desc:"Image Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"imgminor",
				Desc:"Image Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"subsysmajor",
				Desc:"Sub-System Major Version",
				Type:['uhex','',2],
			},
			{
				Name:"subsysminor",
				Desc:"Sub-System Minor Version",
				Type:['uhex','',2],
			},
			{
				Name:"w32ver",
				Desc:"Windows 32 Version",
				Type:['uhex','',4],
			},
			{
				Name:"imgsize",
				Desc:"Image Size",
				Type:['uhex','',4],
			},
			{
				Name:"hdsize",
				Desc:"Header Size",
				Type:['uhex','',4],
			},
			{
				Name:"checksum",
				Desc:"Check Sum",
				Type:['uhex','',4],
			},
			{
				Name:"imgsubsys",
				Desc:"Image Sub-System",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=["Unknown sub-system",
						   "Native",
						   "Windows GUI",
						   "Windows CLI",
						   "Unknown sub-system",
						   "OS/2",
						   "Unknown sub-system",
						   "Posix",
						   "Native Windows 9x Driver",
						   "Windows CE GUI",
						   "EFI Application",
						   "EFI Boot Service Driver",
						   "EFI Runtime Driver",
						   "EFI ROM",
						   "XBOX",
						   "Unknown sub-system",
						   "Windows Boot Application"],t=parseInt(This.Val.imgsubsys,16),Result=[0,1];
					if((t<0)||(t>=v.length))
					{
						t=0;
						Result[1]=-1;
					}
					Result[0]=v[t];
					return Result;
				}
			},
			{
				Name:"dllchars",
				Desc:"DLL Characteristics",
				Type:['uhex','',2],
				Value:function(Parameters,This,Base)
				{
					var v=parseInt(This.Val.dllchars,16),r='';
					if(v&64)
					{
						r+="Dynamical Base<br>";
					}
					if(v&128)
					{
						r+="Code Integrity Image<br>";
					}
					if(v&256)
					{
						r+="NX Compatible<Br>";
					}
					if(v&512)
					{
						r+="No isolation<br>";
					}
					if(v&1024)
					{
						r+="No SEH<br>";
					}
					if(v&2048)
					{
						r+="No Bind<br>";
					}
					if(v&8192)
					{
						r+="WDM Driver<br>";
					}
					if(v&32768)
					{
						r+="Terminate Service Aware<br>";
					}
					return [r,0];
				}
			},
			{
				Name:"stacksize",
				Desc:"Reserved Stack Size",
				Type:['uhex','',8],
			},
			{
				Name:"stackcommitsize",
				Desc:"Committed Stack Size",
				Type:['uhex','',8],
			},
			{
				Name:"heapsize",
				Desc:"Reserved Heap Size",
				Type:['uhex','',8],
			},
			{
				Name:"heapcommitsize",
				Desc:"Committed Heap Size",
				Type:['uhex','',8],
			},
			{
				Name:"loaderflags",
				Desc:"Loader Flags",
				Type:['uhex','',4],
			},
			{
				Name:"rvacount",
				Desc:"RVA Table Count",
				Type:['uhex','',4],
			},
		],
		Next:function(Parameters,This,Base)
		{
			var d=[
				{Name:"export",Desc:"Export",Type:["File_mspedatadir","",8]},
				{Name:"import",Desc:"Import",Type:["File_mspedatadir","",8]},
				{Name:"resource",Desc:"Resource",Type:["File_mspedatadir","",8]},
				{Name:"exception",Desc:"Exception",Type:["File_mspedatadir","",8]},
				{Name:"security",Desc:"Security",Type:["File_mspedatadir","",8]},
				{Name:"relocatetable",Desc:"RelocationTable",Type:["File_mspedatadir","",8]},
				{Name:"debug",Desc:"DebugDirectory",Type:["File_mspedatadir","",8]},
				{Name:"copyright",Desc:"CopyrightOrArchitectureSpecificData",Type:["File_mspedatadir","",8]},
				{Name:"global",Desc:"GlobalPtr",Type:["File_mspedatadir","",8]},
				{Name:"tls",Desc:"TLSDirectory",Type:["File_mspedatadir","",8]},
				{Name:"config",Desc:"LoadConfigurationDirectory",Type:["File_mspedatadir","",8]},
				{Name:"bound",Desc:"BoundImportDirectory",Type:["File_mspedatadir","",8]},
				{Name:"importaddrtable",Desc:"ImportAddressTable",Type:["File_mspedatadir","",8]},
				{Name:"delayload",Desc:"DelayLoadImportDescriptors",Type:["File_mspedatadir","",8]},
				{Name:"com",Desc:"COMRuntimedescriptor",Type:["File_mspedatadir","",8]},
				{Name:"reserved",Desc:"Reserved",Type:["File_mspedatadir","",8]}
			],v=parseInt(This.Val.rvacount,16);
			
			if(v>16)
			{
				v=16;
			}
			return d.slice(0,v);
		}
	};
	
	if(gStructureParser==undefined)
		setTimeout(RegisterStructures,200);
	else
	{
		gStructureParser.Register(mzheader);
		gStructureParser.Register(datadir);
		gStructureParser.Register(peheader);
		gStructureParser.Register(optheader);
		gStructureParser.Register(optheader32);
		gStructureParser.Register(optheader64);
	}
}

